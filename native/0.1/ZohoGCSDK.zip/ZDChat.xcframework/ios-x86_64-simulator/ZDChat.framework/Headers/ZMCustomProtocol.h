//
//  ZMCustomProtocol.h
//  desk-manager
//
//  Created by rajeshkumar.l on 25/06/18.
//  Copyright © 2018 Zoho. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZMCustomProtocol : NSURLProtocol

@end
