//
//  ZDGC.h
//  ZDGC
//
//  Created by Rajeshkumar Lingavel on 06/03/20.
//  Copyright © 2020 Rajeshkumar Lingavel. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ZDGC.
FOUNDATION_EXPORT double ZDGCVersionNumber;

//! Project version string for ZDGC.
FOUNDATION_EXPORT const unsigned char ZDGCVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZDGC/PublicHeader.h>

#import <ZDChat/ZMCustomProtocol.h>
#import <ZDChat/NSURLProtocolWKWebViewSupport.h>
